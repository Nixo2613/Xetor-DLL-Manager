import sys
import requests
import socket
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QMessageBox
)
from PyQt6.QtGui import QIcon  # Import ajouté

class IPFinder(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("IP WAN + IP Locale Search")
        self.setFixedSize(350, 220)

        # Définir l'icône de la fenêtre
        self.setWindowIcon(QIcon("icon.ico"))

        layout = QVBoxLayout()

        self.ip_wan_label = QLabel("IP WAN (publique) : ---")
        layout.addWidget(self.ip_wan_label)

        self.ip_local_label = QLabel("IP locale (LAN) : ---")
        layout.addWidget(self.ip_local_label)

        self.search_button = QPushButton("Chercher IP WAN & Locale")
        self.search_button.clicked.connect(self.search_ips)
        layout.addWidget(self.search_button)

        self.copy_local_button = QPushButton("Copier uniquement IP locale")
        self.copy_local_button.clicked.connect(self.copy_local_ip)
        layout.addWidget(self.copy_local_button)

        self.setLayout(layout)

        # Stockage des IP pour copie
        self.current_local_ip = None

    def search_ips(self):
        # IP WAN
        try:
            ip_wan = requests.get("https://api.ipify.org").text
            self.ip_wan_label.setText(f"IP WAN (publique) : {ip_wan}")
        except Exception as e:
            self.ip_wan_label.setText(f"Erreur IP WAN : {e}")
            ip_wan = None

        # IP locale
        try:
            hostname = socket.gethostname()
            ip_local = socket.gethostbyname(hostname)
            self.ip_local_label.setText(f"IP locale (LAN) : {ip_local}")
            self.current_local_ip = ip_local
        except Exception as e:
            self.ip_local_label.setText(f"Erreur IP locale : {e}")
            self.current_local_ip = None

        # Copier les deux IP dans le presse-papiers
        if ip_wan and self.current_local_ip:
            ips_text = f"IP WAN: {ip_wan}\nIP Locale: {self.current_local_ip}"
            clipboard = QApplication.instance().clipboard()
            clipboard.setText(ips_text)
            QMessageBox.information(self, "Copié", "Les IP WAN et locale ont été copiées dans le presse-papiers.")

    def copy_local_ip(self):
        if self.current_local_ip:
            clipboard = QApplication.instance().clipboard()
            clipboard.setText(self.current_local_ip)
            QMessageBox.information(self, "Copié", f"L'adresse IP locale ({self.current_local_ip}) a été copiée.")
        else:
            QMessageBox.warning(self, "Erreur", "Aucune IP locale trouvée, veuillez chercher les IP d'abord.")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = IPFinder()
    window.show()
    sys.exit(app.exec())
