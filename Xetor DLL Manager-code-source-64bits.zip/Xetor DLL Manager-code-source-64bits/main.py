import tkinter as tk
from tkinter import filedialog, messagebox
import zipfile
import os
import shutil
import tempfile
import sys

class XDLLManagerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("XDLL Manager")
        self.root.geometry("800x500")
        self.root.resizable(False, False)

        try:
            icon_path = os.path.abspath("iconXdll.ico")
            self.root.iconbitmap("icon.ico")
        except Exception as e:
            print("Erreur chargement icône :", e)

        self.current_file = None
        self.file_list = []
        self.temp_dir = tempfile.mkdtemp()

        self.create_widgets()

        if len(sys.argv) > 1:
            path = sys.argv[1]
            if os.path.isfile(path) and path.endswith(".xdll"):
                self.open_xdll(path)

        self.root.protocol("WM_DELETE_WINDOW", self.quit_app)

    def create_widgets(self):
        top_frame = tk.Frame(self.root)
        top_frame.pack(fill=tk.X, padx=5, pady=5, anchor='nw')

        quit_button = tk.Button(top_frame, text="Quitter", command=self.quit_app)
        quit_button.pack(side=tk.LEFT)

        self.listbox = tk.Listbox(self.root, width=100, height=20)
        self.listbox.pack(padx=10, pady=10, expand=True)

        button_frame = tk.Frame(self.root)
        button_frame.pack(pady=5)

        buttons = [
            ("Ouvrir", self.browse_xdll),
            ("Ajouter", self.add_file),
            ("Supprimer", self.remove_file),
            ("Extraire", self.extract_files),
            ("Créer", self.create_new),
            ("Sauver", self.save_xdll),
            ("Fermer", self.close_xdll)
        ]

        for i, (label, command) in enumerate(buttons):
            tk.Button(button_frame, text=label, width=12, command=command).grid(row=0, column=i, padx=5)

        self.status = tk.StringVar()
        self.status.set("Aucun fichier chargé.")
        tk.Label(self.root, textvariable=self.status, bd=1, relief=tk.SUNKEN, anchor=tk.W).pack(fill=tk.X, side=tk.BOTTOM)

    def browse_xdll(self):
        path = filedialog.askopenfilename(filetypes=[("XDLL Files", "*.xdll")])
        if path:
            self.open_xdll(path)

    def open_xdll(self, path):
        try:
            self.clear_temp()
            with zipfile.ZipFile(path, 'r') as zip_ref:
                zip_ref.extractall(self.temp_dir)
            self.current_file = path
            self.refresh_list()
            self.status.set(f"Ouvert : {os.path.basename(path)}")
        except Exception as e:
            messagebox.showerror("Erreur", f"Impossible d'ouvrir le fichier : {e}")

    def refresh_list(self):
        self.file_list = []
        self.listbox.delete(0, tk.END)
        for root_dir, _, files in os.walk(self.temp_dir):
            for file in files:
                full_path = os.path.join(root_dir, file)
                rel_path = os.path.relpath(full_path, self.temp_dir)
                self.file_list.append(rel_path)
                self.listbox.insert(tk.END, rel_path)

    def add_file(self):
        files = filedialog.askopenfilenames(title="Ajouter des fichiers")
        for file in files:
            try:
                dest = os.path.join(self.temp_dir, os.path.basename(file))
                shutil.copy(file, dest)
            except Exception as e:
                messagebox.showerror("Erreur", f"Impossible d'ajouter le fichier : {e}")
        self.refresh_list()

    def remove_file(self):
        selected = self.listbox.curselection()
        if not selected:
            messagebox.showinfo("Info", "Aucun fichier sélectionné.")
            return
        for i in reversed(selected):
            file_to_delete = os.path.join(self.temp_dir, self.file_list[i])
            try:
                os.remove(file_to_delete)
            except:
                pass
        self.refresh_list()

    def extract_files(self):
        selected = self.listbox.curselection()
        if not selected:
            messagebox.showinfo("Info", "Aucun fichier sélectionné.")
            return
        dest_dir = filedialog.askdirectory(title="Choisir un dossier d'extraction")
        if not dest_dir:
            return
        for i in selected:
            file_rel = self.file_list[i]
            src_path = os.path.join(self.temp_dir, file_rel)
            try:
                shutil.copy(src_path, os.path.join(dest_dir, os.path.basename(file_rel)))
            except Exception as e:
                messagebox.showerror("Erreur", f"Impossible d'extraire le fichier : {e}")
        messagebox.showinfo("Succès", "Fichiers extraits avec succès.")

    def save_xdll(self):
        if not self.file_list:
            messagebox.showinfo("Info", "Aucun fichier à sauvegarder.")
            return
        save_path = filedialog.asksaveasfilename(defaultextension=".xdll", filetypes=[("XDLL Files", "*.xdll")])
        if not save_path:
            return
        try:
            with zipfile.ZipFile(save_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for file in self.file_list:
                    abs_path = os.path.join(self.temp_dir, file)
                    zipf.write(abs_path, arcname=file)
            self.current_file = save_path
            self.status.set(f"Sauvegardé : {os.path.basename(save_path)}")
            messagebox.showinfo("Succès", "Archive sauvegardée avec succès.")
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors de la sauvegarde : {e}")

    def create_new(self):
        self.clear_temp()
        self.refresh_list()
        self.current_file = None
        self.status.set("Nouvelle archive créée.")

    def close_xdll(self):
        self.clear_temp()
        self.refresh_list()
        self.current_file = None
        self.status.set("Aucun fichier chargé.")

    def clear_temp(self):
        if os.path.exists(self.temp_dir):
            for root_dir, _, files in os.walk(self.temp_dir):
                for file in files:
                    try:
                        os.remove(os.path.join(root_dir, file))
                    except:
                        pass

    def quit_app(self):
        self.clear_temp()
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = XDLLManagerApp(root)
    root.protocol("WM_DELETE_WINDOW", app.quit_app)
    root.mainloop()
