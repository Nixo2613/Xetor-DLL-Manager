import tkinter as tk
from tkinter import colorchooser, filedialog
from PIL import Image, ImageTk, ImageDraw

WIDTH, HEIGHT = 600, 400
BG_COLOR = "white"

current_tool = "pencil"
current_color = "black"
drawing = False
start_x = start_y = 0
current_file = None
scale = 1.0
zoom_step = 0.1
preview_shape = None
history = []

root = tk.Tk()
root.title("Éditeur de dessin complet")

# Ajout de l'icône de l'application (icon1.ico doit être dans le même dossier)
try:
    root.iconbitmap("icon1.ico")
except Exception as e:
    print("Impossible de charger l'icône de la fenêtre :", e)

# Création de l'image vide
image = Image.new("RGB", (WIDTH, HEIGHT), BG_COLOR)
draw = ImageDraw.Draw(image)
history.append(image.copy())  # Premier état sauvegardé dans l'historique
tk_image = ImageTk.PhotoImage(image)

canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT, bg=BG_COLOR)
canvas_img = canvas.create_image(0, 0, anchor="nw", image=tk_image)
canvas.pack()

def update_canvas():
    global tk_image
    resized = image.resize((int(WIDTH * scale), int(HEIGHT * scale)), Image.NEAREST)
    tk_image = ImageTk.PhotoImage(resized)
    canvas.itemconfig(canvas_img, image=tk_image)

def choose_color():
    global current_color
    color = colorchooser.askcolor(title="Choisir une couleur")
    if color[1]:
        current_color = color[1]

def set_tool(tool_name):
    global current_tool
    current_tool = tool_name

def on_mouse_down(event):
    global drawing, start_x, start_y
    drawing = True
    start_x, start_y = int(event.x / scale), int(event.y / scale)
    if current_tool == "fill":
        target_color = image.getpixel((start_x, start_y))
        if target_color != hex_to_rgb(current_color):
            history.append(image.copy())
            flood_fill(start_x, start_y, target_color, hex_to_rgb(current_color))
            update_canvas()

def on_mouse_move(event):
    global preview_shape
    if not drawing:
        return
    x, y = int(event.x / scale), int(event.y / scale)
    if current_tool == "pencil":
        draw.line([start_x, start_y, x, y], fill=current_color, width=2)
        update_canvas()
        globals()["start_x"], globals()["start_y"] = x, y
    elif current_tool in ("rectangle", "circle"):
        canvas.delete("preview")
        if current_tool == "rectangle":
            preview_shape = canvas.create_rectangle(
                start_x * scale, start_y * scale, event.x, event.y,
                outline=current_color, width=2, tags="preview"
            )
        elif current_tool == "circle":
            preview_shape = canvas.create_oval(
                start_x * scale, start_y * scale, event.x, event.y,
                outline=current_color, width=2, tags="preview"
            )

def on_mouse_up(event):
    global drawing
    drawing = False
    x, y = int(event.x / scale), int(event.y / scale)
    if current_tool in ("rectangle", "circle"):
        history.append(image.copy())
        canvas.delete("preview")
        if current_tool == "rectangle":
            draw.rectangle([start_x, start_y, x, y], outline=current_color, width=2)
        elif current_tool == "circle":
            draw.ellipse([start_x, start_y, x, y], outline=current_color, width=2)
        update_canvas()
    elif current_tool == "pencil":
        history.append(image.copy())

def flood_fill(x, y, target_color, replacement_color):
    if target_color == replacement_color:
        return
    stack = [(x, y)]
    while stack:
        x, y = stack.pop()
        try:
            if image.getpixel((x, y)) == target_color:
                image.putpixel((x, y), replacement_color)
                stack.extend([(x+1, y), (x-1, y), (x, y+1), (x, y-1)])
        except IndexError:
            continue

def hex_to_rgb(hex_color):
    hex_color = hex_color.lstrip("#")
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

def new_image():
    global image, draw, current_file, history
    current_file = None
    image = Image.new("RGB", (WIDTH, HEIGHT), BG_COLOR)
    draw = ImageDraw.Draw(image)
    history = [image.copy()]
    update_canvas()

def save_as():
    global current_file
    file_path = filedialog.asksaveasfilename(
        defaultextension=".png",
        filetypes=[("PNG", "*.png"), ("JPEG", "*.jpg"), ("BMP", "*.bmp")],
        title="Enregistrer sous..."
    )
    if file_path:
        image.save(file_path)
        current_file = file_path

def save_image():
    global current_file
    if current_file:
        image.save(current_file)
    else:
        save_as()

def exit_app():
    root.destroy()

def zoom_canvas(event):
    global scale
    if event.delta > 0:
        scale += zoom_step
    elif event.delta < 0 and scale > zoom_step:
        scale -= zoom_step
    update_canvas()

def undo_action(event=None):
    global image, draw
    if len(history) > 1:
        history.pop()
        image = history[-1].copy()
        draw = ImageDraw.Draw(image)
        update_canvas()

# Création barre de menu Fichier
menubar = tk.Menu(root)
filemenu = tk.Menu(menubar, tearoff=0)
filemenu.add_command(label="Nouveau", command=new_image)
filemenu.add_command(label="Sauvegarder", command=save_image)
filemenu.add_command(label="Sauvegarder sous...", command=save_as)
filemenu.add_separator()
filemenu.add_command(label="Quitter", command=exit_app)
menubar.add_cascade(label="Fichier", menu=filemenu)
root.config(menu=menubar)

# Barre d'outils
tool_frame = tk.Frame(root)
tool_frame.pack(side="top", fill="x", padx=5, pady=5)

tk.Button(tool_frame, text="Couleur", command=choose_color).pack(side="left", padx=5)
tk.Button(tool_frame, text="Crayon", command=lambda: set_tool("pencil")).pack(side="left", padx=5)
tk.Button(tool_frame, text="Rectangle", command=lambda: set_tool("rectangle")).pack(side="left", padx=5)
tk.Button(tool_frame, text="Cercle", command=lambda: set_tool("circle")).pack(side="left", padx=5)
tk.Button(tool_frame, text="Remplir", command=lambda: set_tool("fill")).pack(side="left", padx=5)
tk.Button(tool_frame, text="Effacer", command=new_image).pack(side="left", padx=5)

# Bindings souris et clavier
canvas.bind("<Button-1>", on_mouse_down)
canvas.bind("<B1-Motion>", on_mouse_move)
canvas.bind("<ButtonRelease-1>", on_mouse_up)
canvas.bind("<MouseWheel>", zoom_canvas)
root.bind("<Control-z>", undo_action)

update_canvas()
root.mainloop()
